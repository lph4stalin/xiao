"""
2017/03/08
web10


本课的内容主要是
    前端用 ajax 发送 HTTP 请求到后端
    后端 API
    ajax 跨域
    ajax todo 程序(增强功能)
    ajax weibo 和动态评论



本课新增的文件是
static/gua.js               基础 js
static/todo.js              todo_index.html 里面用的 js
templates/todo_index.html   模板文件
routes/api_todo.py          存放和前端 ajax 交互数据的 todo api
routes/todo.py              简单的页面返回
"""