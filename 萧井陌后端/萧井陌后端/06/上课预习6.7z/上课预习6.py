"""
2017/02/27



0, 改进 log 把记录写入文件


1, 模板和模板使用方法
参考下面 2 个文件
jinja_demo.py
templates/demo.html


2, 用模板实现 todo 程序
参考下面 2 个文件
routes_simpletodo.py
templates/simple_todo_index.html


3, 用模板实现注册/登录
参考下面 2 个文件
routes_user.py
templates/login.html
templates/register.html


4, python package(包, 也就是高级模块)
"""
