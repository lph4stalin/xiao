"""
2017/03/31

web19


web 安全问题
    CSRF
    XSS

部署到服务器
    wsgi.py
    gunicorn
    supervisor
    nginx


在此基础上 开发新功能

板块功能
    板块的添加属于管理员操作
    topic 页面显示所有板块
    添加新 topic 的时候, 需要选择板块
    默认会给你选中当前板块

"""