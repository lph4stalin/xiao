"""
2017/03/17


今天上课开始 我们要使用 flask 框架来替代我们之前实现的 server.py
我们写的 server.py 相当于一个简化版的 flask
本质是一样的, 使用方法也类似



需要安装 flask, 使用 pip 安装如下(不懂就问/等上课)
pip3 install flask
"""