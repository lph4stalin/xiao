# web 8
# 数据库
# 2017/03/03
#

"""
数据库是应用最广泛的计算机软件

本节课讲 sqlite 和 mongodb
sqlite 是 python3 自带的数据库，不用安装
但是需要安装一个叫 sqlitebrowser 的管理软件

mongodb 需要安装，链接如下
软件本身
http://www.runoob.com/mongodb/mongodb-window-install.html
管理软件
https://robomongo.org/download

"""

# 数据库现在主要分 关系型数据库（传统） 和 NoSQL（新式比如 mongodb）
# 和一些其他数据库（比如 fb 的图数据库）
# 本课只讲 关系型数据库 和 mongodb
