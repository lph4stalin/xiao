"""
2017/03/22

web 15


今天上课, 主要是
1, routes/index.py 中的 在 flask 中设置 cookie 和 session 的方法
2, routes/session_exp.py 的 session 和 用户登出
3, 用 博客/留言板 来讲解如何拆分任务
4, 开发的常见方法
"""