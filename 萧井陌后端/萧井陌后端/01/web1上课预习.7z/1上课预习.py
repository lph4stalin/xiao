Web 班准备工作
---
1, 我们使用 Python 3.4 版本
2, 我们使用 Pycharm CE 作为开发工具
3, 上课时间为每周 1 3 5 晚

备注:
操作系统不限



上课方式
---
QQ 群视频，只有手机 QQ 和 Windows QQ 能看到
Mac QQ 不能看到
iPad 需要安装手机 QQ 才能看



上课文件
---
Web课课件1.rtf 是理论知识, 看看大致理解, 不要求记忆
client.py 是使用 python socket 库进行网络编程, 实现 HTTP 客户端(比如浏览器)的程序
http1.py 是使用 python socket 库进行网络编程, 实现 HTTP 服务端的程序

配合代码的注释, 理解代码, 把不懂的地方记下来, 方便上课问



课程参考书
---
如果 Python 基础不扎实, 可以参考 Python 学习手册
HTML CSS 知识只推荐一本(之后会有专门的课讲解 CSS), 自行学习 https://item.jd.com/1060167433.html
