import rpcserver

s = rpcserver.RPCServer()
s.loop()
